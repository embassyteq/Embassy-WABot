# WhatsApp Bot

Basic WhatsApp bot using Baileys and Node.js.

## Setup
1. Run `npm install`
2. Start the bot with `npm start`
3. Scan the QR code
